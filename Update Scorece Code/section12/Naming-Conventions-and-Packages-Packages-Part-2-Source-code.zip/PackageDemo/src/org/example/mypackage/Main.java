package org.example.mypackage;

/**
 * Created by dev on 30/10/2015.
 */
public class Main {
}
