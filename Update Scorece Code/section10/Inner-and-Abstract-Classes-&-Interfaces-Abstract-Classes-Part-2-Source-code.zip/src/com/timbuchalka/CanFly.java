package com.timbuchalka;

/**
 * Created by dev on 9/10/2015.
 */
public interface CanFly {
    void fly();
}
