package com.timbuchalka;

import static junit.framework.TestCase.fail;

/**
 * Created by timbuchalka on 20/11/16.
 */
public class BankAccountTest {
    @org.junit.Test
    public void deposit() throws Exception {
        fail("This test has yet to be implemented");
    }

    @org.junit.Test
    public void withdraw() throws Exception {
        fail("This test has yet to be implemented");
    }

    @org.junit.Test
    public void getBalance() throws Exception {
        fail("This test has yet to be implemented");
    }

}