package com.timbuchalka;

public class Main {

    public static void main(String[] args) {


        javafx.scene.Node node = null;
        org.w3c.dom.Node anotherNode = null;
    }
}
