package com.timbuchalka;

public class Main {

    public static void main(String[] args) {
        Utilities util = new Utilities();
        util.removePairs("AABCDDEFF");
    }
}
