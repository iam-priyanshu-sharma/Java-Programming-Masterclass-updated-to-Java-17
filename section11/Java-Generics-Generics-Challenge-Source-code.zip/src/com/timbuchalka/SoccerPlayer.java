package com.timbuchalka;

/**
 * Created by dev on 17/10/2015.
 */
public class SoccerPlayer extends Player {

    public SoccerPlayer(String name) {
        super(name);
    }
}
