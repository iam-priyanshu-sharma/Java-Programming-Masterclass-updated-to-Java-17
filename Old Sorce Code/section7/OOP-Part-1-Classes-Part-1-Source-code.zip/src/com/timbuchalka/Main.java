package com.timbuchalka;

public class Main {

    public static void main(String[] args) {
	    Car porsche = new Car();
        Car holden = new Car();
        porsche.model = "Carrera";
    }
}
