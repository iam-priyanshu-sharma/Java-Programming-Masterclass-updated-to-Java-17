package com.timbuchalka;

/**
 * Created by dev on 17/10/2015.
 */
public class FootballPlayer extends Player {

    public FootballPlayer(String name) {
        super(name);
    }
}
