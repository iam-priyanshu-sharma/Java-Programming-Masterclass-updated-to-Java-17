package sample;

import javafx.fxml.FXML;

public class Controller {

    @FXML
    public void showAddContactDialog() {

    }
}
