package com.timbuchalka;

public class Main {

    public static void main(String[] args) {
	    final Worker worker1 = new Worker("Worker 1", true);
        final Worker worker2 = new Worker("Worker 2", true);


    }
}
