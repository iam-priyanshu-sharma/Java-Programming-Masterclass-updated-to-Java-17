package com.timbuchalka;

/**
 * Created by dev on 8/3/15.
 */
public class Vehicle {
    private String name;

    public Vehicle(String name) {
        this.name = name;
    }
}
